1. composer install

2. npm install

3. cp .env.example .env

4. php artisan key:generate


After install and setup use 

1. php artisan migrate

2. php artisan db:seed --class=UserSeeder