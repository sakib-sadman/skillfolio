


<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <?php if(\Session::has('success')): ?>
    <div class="row">
        <div class="col-md-12">
            <div id="notificationAlert" style="display: block;">

                <div class="alert alert-warning">
                    <span style="color:black;">
                        <?php echo \Session::get('success'); ?>

                    </span>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="d-flex justify-content-between">
        <div>
            <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">User /</span> list</h4>
        </div>
        <div class="my-auto">
            <a href="<?php echo e(route('users.create')); ?>">
                <button class="btn btn-info rounded-pill">Add User</button>
            </a>
        </div>
    </div>
    <!-- Basic Bootstrap Table -->
    <div class="card">

        <div class="table-responsive text-nowrap p-4">
            <table class="table" id="DataTable">
                <thead>
                    <tr>
                        <th>SL</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Role</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php if($users->isNotEmpty()): ?>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td>
                            <img src="<?php echo e(Storage::url($data->image->url ?? '' )); ?>" alt="User Image" style="max-width: 100px;max-height:80px;">
                        </td>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->getRoleNames()[0] ?? 'user'); ?></td>
                        <td><?php echo e(date('h:ia', strtotime($data->created_at))); ?> <br>
                            <?php echo e(date('d M, Y', strtotime($data->created_at))); ?>

                        </td>
                        <td><?php echo e(($data->status == 1) ? 'Active' : 'Disabled'); ?></td>
                        <td>
                             <?php if($data->status == 1): ?>
                                <a href="<?php echo e(route('user-account-status-toggle', $data->id)); ?>" class="btn btn-dark btn-sm" onclick="confirm('Are you sure you want to Lock this User?')" ><i class="fa fa-lock"></i></a>  
                                
                            <?php else: ?>
                                <a href="<?php echo e(route('user-account-status-toggle', $data->id)); ?>" class="btn btn-dark btn-sm" onclick="confirm('Are you sure you want to unlock this User?')"><i class="fa fa-unlock-alt"></i></a>  
                                
                            <?php endif; ?>
                            <a href="<?php echo e(route('users.edit', $data->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></a>  
                            <a href="#" onclick="if(!confirm('Are you sure you want to delete this User?')){event.preventDefault();}else{document.getElementById('delete-form-<?php echo e($key); ?>').submit();}"
                                    class="btn btn-danger btn-sm"><i class="fa fa-trash"></i>
                            </a>
                                
                            <form id="delete-form-<?php echo e($key); ?>" action="<?php echo e(route('users.destroy', $data->id)); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>

                           

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
    <!--/ Basic Bootstrap Table -->



</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_css'); ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_js'); ?>
<script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap4.min.js"></script>
<script>
    $('#notificationAlert').delay(3000).fadeOut('slow');
    $(document).ready(function () {
        $('#DataTable').DataTable();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminpanel.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\yeamin\Project\Skillfolio\resources\views/adminpanel/users/index.blade.php ENDPATH**/ ?>